from __future__ import annotations
import base64, hmac, http.client, json, mimetypes, os
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
PORT = int(os.getenv('PORT','8080'))
STAGING = os.getenv('STAGING_MODE','1').strip().lower() in {'1','true','yes','on'}
ADMIN_USER = os.getenv('ADMIN_USER','admin')
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD','')

UPSTREAMS = {
    '/app': ('127.0.0.1', 8790),
    '/contrata': ('127.0.0.1', 8792),
    '/nexo': ('127.0.0.1', 8793),
    '/sinal': ('127.0.0.1', 8794),
    '/kit': ('127.0.0.1', 8787),
}
KIT_BACKEND = ('/health','/ready','/ecosystem/','/claim/','/access/','/admin/','/webhook/','/test/')
HOP = {'connection','keep-alive','proxy-authenticate','proxy-authorization','te','trailers','transfer-encoding','upgrade'}


def _safe_file(base: Path, rel: str):
    base = base.resolve()
    target = (base / rel.lstrip('/')).resolve()
    try: target.relative_to(base)
    except ValueError: return None
    return target


class H(BaseHTTPRequestHandler):
    server_version = 'MEIGrowthGateway/1.0'
    def log_message(self, fmt, *args):
        # Do not print Authorization or request bodies.
        print(f'{self.address_string()} - {fmt % args}', flush=True)

    def _security(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Referrer-Policy','strict-origin-when-cross-origin')
        self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=()')
        if STAGING: self.send_header('X-Robots-Tag','noindex, nofollow, noarchive')

    def _auth_ok(self):
        if not ADMIN_PASSWORD: return False
        v = self.headers.get('Authorization','')
        if not v.lower().startswith('basic '): return False
        try:
            raw = base64.b64decode(v.split(' ',1)[1], validate=True).decode('utf-8')
            user, pwd = raw.split(':',1)
        except Exception:
            return False
        return hmac.compare_digest(user, ADMIN_USER) and hmac.compare_digest(pwd, ADMIN_PASSWORD)

    def _needs_auth(self, path: str):
        if path in ('/health','/ready'): return False
        if STAGING: return True
        if path == '/app' or path.startswith('/app/'): return True
        if path == '/contrata' or path.startswith('/contrata/'): return True
        if path == '/nexo' or path.startswith('/nexo/'): return True
        if path.startswith('/sinal/api/signals'): return True
        if path.startswith('/kit/admin/'): return True
        return False

    def _guard(self):
        path = urlsplit(self.path).path
        if self._needs_auth(path) and not self._auth_ok():
            body=b'Authentication required'
            self.send_response(401); self.send_header('WWW-Authenticate','Basic realm="MEI Growth"')
            self._security(); self.send_header('Content-Type','text/plain; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
            return False
        return True

    def _redirect(self, target):
        self.send_response(308); self._security(); self.send_header('Location',target); self.send_header('Content-Length','0'); self.end_headers()

    def _serve_file(self, base: Path, rel: str):
        if not rel or rel.endswith('/'): rel += 'index.html'
        p=_safe_file(base,rel)
        if not p or not p.is_file(): return False
        data=p.read_bytes(); ctype=mimetypes.guess_type(p.name)[0] or 'application/octet-stream'
        self.send_response(200); self._security(); self.send_header('Content-Type',ctype + ('; charset=utf-8' if ctype.startswith('text/') else ''))
        self.send_header('Content-Length',str(len(data))); self.send_header('Cache-Control','no-store' if STAGING else 'public, max-age=300'); self.end_headers(); self.wfile.write(data); return True

    def _proxy(self, prefix: str, upstream):
        split=urlsplit(self.path)
        path=split.path[len(prefix):] or '/'
        if split.query: path += '?' + split.query
        try: n=int(self.headers.get('Content-Length','0') or 0)
        except: n=0
        body=self.rfile.read(n) if n>0 else None
        headers={}
        for k,v in self.headers.items():
            if k.lower() in HOP or k.lower() in {'host','content-length'}: continue
            headers[k]=v
        if body is not None: headers['Content-Length']=str(len(body))
        headers['Host']=f'{upstream[0]}:{upstream[1]}'
        headers['X-Forwarded-Host']=self.headers.get('Host','')
        headers['X-Forwarded-Proto']=self.headers.get('X-Forwarded-Proto','https')
        conn=http.client.HTTPConnection(upstream[0],upstream[1],timeout=30)
        try:
            conn.request(self.command,path,body=body,headers=headers)
            r=conn.getresponse(); data=r.read()
            self.send_response(r.status,r.reason); self._security()
            for k,v in r.getheaders():
                if k.lower() in HOP or k.lower() in {'server','date','content-length'}: continue
                self.send_header(k,v)
            self.send_header('Content-Length',str(len(data))); self.end_headers()
            if self.command!='HEAD': self.wfile.write(data)
        except Exception:
            data=b'Upstream unavailable'; self.send_response(502); self._security(); self.send_header('Content-Type','text/plain'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        finally: conn.close()

    def _dispatch(self):
        if not self._guard(): return
        split=urlsplit(self.path); path=split.path
        if path=='/health':
            statuses={}
            for name,(host,port) in UPSTREAMS.items():
                try:
                    c=http.client.HTTPConnection(host,port,timeout=1); c.request('GET','/health'); r=c.getresponse(); r.read(); statuses[name.lstrip('/')]=r.status==200; c.close()
                except Exception: statuses[name.lstrip('/')]=False
            ok=all(statuses.values())
            data=json.dumps({'ok':ok,'version':'railway-1.0','staging':STAGING,'services':statuses}).encode()
            self.send_response(200 if ok else 503); self._security(); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if path=='/ready':
            data=json.dumps({'ready':True,'staging':STAGING,'commerce_enabled':False,'government_submission_enabled':False}).encode()
            self.send_response(200); self._security(); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        for prefix in ('/app','/contrata','/nexo','/sinal','/kit'):
            if path==prefix: return self._redirect(prefix+'/')
        if path.startswith('/kit/'):
            stripped=path[len('/kit'):]
            if any(stripped==x or stripped.startswith(x) for x in KIT_BACKEND): return self._proxy('/kit',UPSTREAMS['/kit'])
            if self.command not in ('GET','HEAD'): return self._proxy('/kit',UPSTREAMS['/kit'])
            if self._serve_file(ROOT/'apps/kitvende/public_site', stripped): return
            self.send_error(404); return
        for prefix in ('/app','/contrata','/nexo','/sinal'):
            if path.startswith(prefix+'/'): return self._proxy(prefix,UPSTREAMS[prefix])
        if self.command in ('GET','HEAD'):
            rel=path.lstrip('/') or 'index.html'
            if self._serve_file(ROOT/'portal',rel): return
        self.send_error(404)

    do_GET=_dispatch
    do_POST=_dispatch
    do_OPTIONS=_dispatch
    do_HEAD=_dispatch


def main():
    print(f'MEI Growth Railway gateway on 0.0.0.0:{PORT} staging={STAGING}',flush=True)
    ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()

if __name__=='__main__': main()
