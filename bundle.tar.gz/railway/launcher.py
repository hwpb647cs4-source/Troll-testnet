from __future__ import annotations
import os, shutil, signal, sqlite3, subprocess, sys, threading, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=Path(os.getenv('DATA_DIR','/data'))
UID=int(os.getenv('APP_UID','10001')); GID=int(os.getenv('APP_GID','10001'))
PROCS=[]

def ensure_runtime(link: Path, target: Path):
    target.mkdir(parents=True,exist_ok=True)
    if link.is_symlink() or link.exists():
        if link.is_symlink(): link.unlink()
        elif link.is_dir(): shutil.rmtree(link)
        else: link.unlink()
    link.parent.mkdir(parents=True,exist_ok=True)
    link.symlink_to(target,target_is_directory=True)

def prepare():
    DATA.mkdir(parents=True,exist_ok=True)
    mappings={
      ROOT/'apps/growthos/runtime': DATA/'growthos',
      ROOT/'apps/contratalens/runtime': DATA/'contratalens',
      ROOT/'apps/nexomei/runtime': DATA/'nexomei',
      ROOT/'apps/sinalmei/runtime': DATA/'sinalmei',
      ROOT/'apps/kitvende/ops/runtime': DATA/'kitvende',
    }
    for link,target in mappings.items():
        target.mkdir(parents=True,exist_ok=True)
        if os.geteuid()==0:
            os.chown(target,UID,GID)
        ensure_runtime(link,target)
    b=DATA/'backups'; b.mkdir(exist_ok=True)
    if os.geteuid()==0:
        os.chown(DATA,UID,GID); os.chown(b,UID,GID)
        os.setgid(GID); os.setuid(UID)

def start(name,cwd,args,extra=None):
    env=os.environ.copy(); env['PYTHONUNBUFFERED']='1'; env.update(extra or {})
    p=subprocess.Popen(args,cwd=str(cwd),env=env)
    PROCS.append((name,p)); print(f'started {name} pid={p.pid}',flush=True)

def backup_once():
    ts=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime()); out=DATA/'backups'/ts; out.mkdir(parents=True,exist_ok=True)
    for d in ['growthos','contratalens','nexomei','sinalmei','kitvende']:
        for src in (DATA/d).glob('*.sqlite3'):
            try:
                dst=out/f'{d}-{src.name}'
                a=sqlite3.connect(src); b=sqlite3.connect(dst); a.backup(b); b.close(); a.close()
            except Exception as e: print(f'backup {src}: {e}',file=sys.stderr,flush=True)
    keep=int(os.getenv('BACKUP_RETENTION_DAYS','14')); cutoff=time.time()-keep*86400
    for p in (DATA/'backups').iterdir():
        try:
            if p.is_dir() and p.stat().st_mtime<cutoff: shutil.rmtree(p)
        except Exception: pass

def backup_loop():
    first=max(60,int(os.getenv('BACKUP_INITIAL_DELAY_SECONDS','300'))); every=max(3600,int(os.getenv('BACKUP_INTERVAL_SECONDS','86400')))
    time.sleep(first)
    while True:
        backup_once(); time.sleep(every)

def shutdown(*_):
    for _,p in PROCS:
        if p.poll() is None: p.terminate()
    deadline=time.time()+8
    for _,p in PROCS:
        if p.poll() is None:
            try: p.wait(max(0,deadline-time.time()))
            except: p.kill()
    raise SystemExit(0)

def main():
    prepare(); signal.signal(signal.SIGTERM,shutdown); signal.signal(signal.SIGINT,shutdown)
    py=sys.executable
    start('growthos',ROOT/'apps/growthos',[py,'-m','engine.server'],{'MEI_GROWTH_OS_HOST':'127.0.0.1','MEI_GROWTH_OS_PORT':'8790'})
    start('contratalens',ROOT/'apps/contratalens',[py,'-m','engine.server'],{'CONTRATALENS_HOST':'127.0.0.1','CONTRATALENS_PORT':'8792'})
    start('nexomei',ROOT/'apps/nexomei',[py,'-m','engine.server'],{'NEXOMEI_HOST':'127.0.0.1','NEXOMEI_PORT':'8793'})
    start('sinalmei',ROOT/'apps/sinalmei',[py,'-m','engine.server'],{'SINALMEI_HOST':'127.0.0.1','SINALMEI_PORT':'8794'})
    kit_env={'KITVENDE_HOST':'127.0.0.1','KITVENDE_PORT':'8787','KITVENDE_PRODUCTION':os.getenv('KITVENDE_PRODUCTION','0'),'KITVENDE_TEST_MODE':'0'}
    start('kitvende',ROOT/'apps/kitvende',[py,'server/app.py'],kit_env)
    if os.getenv('CONTRATALENS_LIVE_SYNC','0').lower() in {'1','true','yes','on'}:
        start('contratalens-sync',ROOT/'apps/contratalens',[py,'-m','engine.scheduler'])
    threading.Thread(target=backup_loop,daemon=True).start()
    time.sleep(2)
    start('gateway',ROOT,[py,'railway/gateway.py'])
    while True:
        for name,p in list(PROCS):
            code=p.poll()
            if code is not None:
                print(f'{name} exited code={code}',file=sys.stderr,flush=True); shutdown()
        time.sleep(2)

if __name__=='__main__': main()
