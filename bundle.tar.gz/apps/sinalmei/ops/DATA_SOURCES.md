# Política de fontes

**Primeira classe:** first-party lead forms/webhooks, referrals e imports autorizados.

**Inteligência agregada:** tendências de busca, sazonalidade, clima e dados públicos de atividade econômica/obras. Esses sinais servem para priorização geográfica/profissional, não para contato individual.

**Marketplaces:** apenas por integração autorizada, export do usuário ou API/termos que permitam. Não fazer scraping autenticado, bypass de controles ou coleta massiva de contatos.
